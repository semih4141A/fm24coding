class InvalidInputError(Exception):
    """Geçersiz kullanıcı girişi için özel hata sınıfı"""
    def __init__(self, message):
        super().__init__(f"Giriş Hatası: {message}")
        self.message = message

class PlayerNotFoundError(Exception):
    """Oyuncu bulunamadığında fırlatılan hata"""
    def __init__(self, criteria):
        super().__init__(f"Verilen kriterlere uygun oyuncu bulunamadı: {criteria}")
        self.criteria = criteria

class SquadFullError(Exception):
    """Kadro doluyken oyuncu eklenmeye çalışıldığında fırlatılan hata"""
    def __init__(self):
        super().__init__("Kadro zaten dolu! Maksimum 11 oyuncu ekleyebilirsiniz.")

class InsufficientPlayersError(Exception):
    """Maça çıkmak için yeterli oyuncu yokken fırlatılan hata"""
    def __init__(self, current_count):
        super().__init__(f"Maça çıkmak için 11 oyuncu gerekli! Şu an {current_count} oyuncunuz var.")
        self.current_count = current_count