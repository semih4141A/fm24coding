Ekip üyeleri: Ataberk Dönmez, Ali Ege Şanverdi, Eren Semih Aktaş

Programın amacı: Belli başlı dataları girerek, bir database'den en uygun oyuncuları
sıralayan bir takım kurma ve bu kurduğumuz takımla yapay zekaya karşı futbol maçı yapma oyunu.
Kısaca bir Scouting oyunu.