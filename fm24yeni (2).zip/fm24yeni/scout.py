class Player:
    def __init__(self, name, age, positions, attributes):
        self.name = name
        self.age = age
        # Pozisyonları string olarak gelirse split et
        if isinstance(positions, str):
            self.positions = [pos.strip() for pos in positions.split(",")]
        else:
            self.positions = positions
        self.attributes = attributes

    def matches(self, age_limit, required_position, criteria):
        # Yaş kontrolü
        if self.age > age_limit:
            return False
        
        # Pozisyon kontrolü - daha esnek
        if required_position not in self.positions:
            # Alternatif pozisyon kontrolleri
            position_alternatives = {
                'ST': ['CF', 'LW', 'RW'],
                'CAM': ['CM', 'LM', 'RM'],
                'CDM': ['CM', 'CB'],
                'LB': ['LWB', 'LM'],
                'RB': ['RWB', 'RM'],
                'CB': ['CDM'],
                'CF': ['ST', 'LW', 'RW'],
                'LW': ['ST', 'LM'],
                'RW': ['ST', 'RM'],
                'CM': ['CAM', 'CDM'],
                'LM': ['LW', 'LB'],
                'RM': ['RW', 'RB']
            }
            
            alternatives = position_alternatives.get(required_position, [])
            if not any(alt in self.positions for alt in alternatives):
                return False
        
        # Özellik kontrolü - biraz daha esnek (3 puan tolerans)
        for attr, min_val in criteria.items():
            if self.attributes.get(attr, 0) < (min_val - 3):
                return False
        
        return True

    def display(self):
        """Oyuncuyu detaylı şekilde yazdır"""
        print(f"\n🌟 {self.name}")
        print(f"📅 Yaş: {self.age}")
        print(f"⚽ Pozisyon: {', '.join(self.positions)}")
        print("📊 Özellikler:")
        for k, v in self.attributes.items():
            print(f"  {k}: {v}")
        print(f"💪 TOPLAM GÜÇ: {sum(self.attributes.values())}")
        print("-" * 40)

    def __str__(self):
        """Oyuncuyu okunabilir formatta döndür (kısa versiyon)"""
        return f"{self.name} (Yaş: {self.age}, Pozisyon: {', '.join(self.positions)})"

    def __repr__(self):
        """Oyuncuyu temsil eden string (detaylı)"""
        return self.__str__()

    def __eq__(self, other):
        """İki oyuncunun eşit olup olmadığını kontrol et"""
        if not isinstance(other, Player):
            return False
        return self.name == other.name and self.age == other.age

    def __hash__(self):
        """Hash fonksiyonu - set ve dict işlemleri için"""
        return hash((self.name, self.age))