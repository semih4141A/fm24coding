import pandas as pd
from scout import Player
from utils import filter_players, sort_players_by_attribute, load_players_from_dataframe
from team_engine import simulate_match
from errors import InvalidInputError
import random
import os

# Global değişkenler
all_players = []
my_squad = []

def load_sample_players():
    """Örnek oyuncu verisi oluştur (CSV dosyası yoksa)"""
    sample_data = [
        {"name": "Haaland", "age": 23, "positions": "ST,CF", "Finishing": 18, "Passing": 12, "First Touch": 15, "Dribbling": 14, "Ball Control": 16},
        {"name": "Mbappe", "age": 24, "positions": "LW,ST,RW", "Finishing": 17, "Passing": 13, "First Touch": 16, "Dribbling": 18, "Ball Control": 17},
        {"name": "Bellingham", "age": 20, "positions": "CAM,CM", "Finishing": 14, "Passing": 16, "First Touch": 17, "Dribbling": 16, "Ball Control": 17},
        {"name": "Pedri", "age": 21, "positions": "CAM,CM", "Finishing": 12, "Passing": 18, "First Touch": 18, "Dribbling": 17, "Ball Control": 18},
        {"name": "Davies", "age": 23, "positions": "LB,LWB", "Finishing": 8, "Passing": 14, "First Touch": 15, "Dribbling": 16, "Ball Control": 15},
        {"name": "Rudiger", "age": 30, "positions": "CB", "Finishing": 6, "Passing": 12, "First Touch": 13, "Dribbling": 10, "Ball Control": 12},
        {"name": "Rice", "age": 24, "positions": "CDM,CM", "Finishing": 10, "Passing": 15, "First Touch": 16, "Dribbling": 13, "Ball Control": 15},
        {"name": "Vinicius", "age": 23, "positions": "LW,LM", "Finishing": 15, "Passing": 13, "First Touch": 16, "Dribbling": 19, "Ball Control": 17},
        {"name": "Salah", "age": 31, "positions": "RW,RM", "Finishing": 17, "Passing": 14, "First Touch": 16, "Dribbling": 17, "Ball Control": 16},
        {"name": "De Bruyne", "age": 32, "positions": "CAM,CM", "Finishing": 14, "Passing": 19, "First Touch": 18, "Dribbling": 16, "Ball Control": 17},
        {"name": "Neuer", "age": 37, "positions": "GK", "Finishing": 3, "Passing": 16, "First Touch": 12, "Dribbling": 8, "Ball Control": 10},
        {"name": "Walker", "age": 33, "positions": "RB,RWB", "Finishing": 7, "Passing": 12, "First Touch": 14, "Dribbling": 13, "Ball Control": 13},
        {"name": "Marquinhos", "age": 29, "positions": "CB,CDM", "Finishing": 8, "Passing": 14, "First Touch": 15, "Dribbling": 12, "Ball Control": 14},
        {"name": "Luka Modric", "age": 38, "positions": "CM,CAM", "Finishing": 12, "Passing": 18, "First Touch": 18, "Dribbling": 17, "Ball Control": 18},
        {"name": "Son", "age": 31, "positions": "LW,ST,RW", "Finishing": 16, "Passing": 13, "First Touch": 15, "Dribbling": 16, "Ball Control": 16},
    ]
    
    for data in sample_data:
        player = Player(
            name=data["name"],
            age=data["age"],
            positions=data["positions"],
            attributes={
                "Finishing": data["Finishing"],
                "Passing": data["Passing"],
                "First Touch": data["First Touch"],
                "Dribbling": data["Dribbling"],
                "Ball Control": data["Ball Control"]
            }
        )
        all_players.append(player)

def load_players():
    """Oyuncu verilerini yükle"""
    csv_path = os.path.join(os.path.dirname(__file__), "data", "players_21.csv")
    abs_path = os.path.abspath(csv_path)
    print(f"Çalışma dizini: {os.getcwd()}")
    print(f"main.py konumu: {os.path.dirname(__file__)}")
    print(f"CSV dosyası kontrol ediliyor: {abs_path}")
    print(f"Dosya mevcut mu?: {os.path.exists(csv_path)}")
    if not os.path.exists(csv_path):
        print(f"⚠️ CSV dosyası bulunamadı: {abs_path}")
        print("Lütfen 'data' klasöründe 'players_21.csv' dosyasının olduğundan emin olun!")
        print("Örnek veriler kullanılıyor...")
        load_sample_players()
        print(f"Örnek oyuncu sayısı: {len(all_players)}")
        print(f"İlk örnek oyuncunun özellikleri: {all_players[0].attributes if all_players else 'Boş'}")
        return

    try:
        df = pd.read_csv(csv_path, encoding='utf-8')
        print("CSV sütunları:", df.columns.tolist())
        print("İlk satır:", df.iloc[0].to_dict())
        required_attrs = ["Finishing", "Passing", "First Touch", "Dribbling", "Ball Control"]
        players = load_players_from_dataframe(df, required_attrs)
        print(f"Yüklenen oyuncu sayısı: {len(players)}")
        print(f"İlk oyuncunun özellikleri: {players[0].attributes if players else 'Boş'}")
        all_players.extend(players)
        print(f"✅ {len(players)} oyuncu CSV'den yüklendi.")
    except UnicodeDecodeError:
        print("⚠️ UTF-8 encoding hatası, latin1 deneniyor...")
        try:
            df = pd.read_csv(csv_path, encoding='latin1')
            print("CSV sütunları:", df.columns.tolist())
            required_attrs = ["Finishing", "Passing", "First Touch", "Dribbling", "Ball Control"]
            players = load_players_from_dataframe(df, required_attrs)
            all_players.extend(players)
            print(f"✅ {len(players)} oyuncu CSV'den yüklendi.")
        except Exception as e:
            print(f"❌ CSV yükleme hatası: {e}")
            print("Örnek veriler kullanılıyor...")
            load_sample_players()
            print(f"Örnek oyuncu sayısı: {len(all_players)}")
    except Exception as e:
        print(f"❌ CSV yükleme hatası: {e}")
        print("Örnek veriler kullanılıyor...")
        load_sample_players()
        print(f"Örnek oyuncu sayısı: {len(all_players)}")

# (Kalan main.py içeriği aynı kalır)

def player_search_menu():
    try:
        print("\n🎯 Oyuncu Arama Menüsü")
        age_limit = int(input("Kaç yaş altı oyuncu arıyorsun? "))
        position = input("Pozisyon (örnek: ST, CAM, CDM, LB): ").upper()

        print("\nAradığın minimum özellik puanlarını gir:")
        finishing = int(input("Bitiricilik (Finishing): "))
        passing = int(input("Pas (Passing): "))
        first_touch = int(input("İlk Dokunuş (First Touch): "))

        criteria = {
            "Finishing": finishing,
            "Passing": passing,
            "First Touch": first_touch
        }

        filtered = filter_players(all_players, age_limit, position, criteria)

        if not filtered:
            print("❌ Uygun oyuncu bulunamadı.")
            print("💡 İpucu: Kriterleri düşürmeyi deneyin.")
        else:
            sorted_players = sort_players_by_attribute(filtered, "Finishing")
            print(f"\n✅ {len(sorted_players)} oyuncu bulundu. En iyi bitiricilere göre sıralanmıştır:\n")
            
            # Oyuncuları DETAYLI göster
            for i, p in enumerate(sorted_players[:20], 1):
                print(f"{i}) {p.name} - Yaş: {p.age} - Poz: {', '.join(p.positions)}")
                print(f"   🎯 Finishing: {p.attributes['Finishing']} | 🔄 Passing: {p.attributes['Passing']} | ⚽ First Touch: {p.attributes['First Touch']}")
                print(f"   🎨 Dribbling: {p.attributes.get('Dribbling', 0)} | 🎱 Ball Control: {p.attributes.get('Ball Control', 0)}")
                print(f"   💪 TOPLAM GÜÇ: {sum(p.attributes.values())}")
                print("-" * 50)
            
            # Kadroya ekleme seçeneği
            while True:
                choice = input("\n[1] Kadroya oyuncu ekle [2] Ana menüye dön - Seçim: ").strip()
                
                if choice == "1":
                    if len(my_squad) >= 11:
                        print("❌ Kadro zaten dolu (max 11 oyuncu)")
                        break
                    
                    try:
                        selections = input("Seçmek istediğin oyuncuların numaralarını gir (örn: 1 3 5): ").split()
                        selected_indices = [int(num)-1 for num in selections if num.isdigit()]
                        
                        added_count = 0
                        for idx in selected_indices:
                            if 0 <= idx < len(sorted_players):
                                if len(my_squad) < 11:
                                    if sorted_players[idx] not in my_squad:
                                        my_squad.append(sorted_players[idx])
                                        print(f"✅ Kadroya eklendi: {sorted_players[idx].name}")
                                        added_count += 1
                                    else:
                                        print(f"⚠️ {sorted_players[idx].name} zaten kadroda!")
                                else:
                                    print("❌ Kadro zaten dolu (max 11 oyuncu)")
                                    break
                            else:
                                print(f"❌ Geçersiz numara: {idx+1}")
                        
                        print(f"\n🎉 {added_count} oyuncu eklendi! Kadroda şu an {len(my_squad)}/11 oyuncu var")
                        
                        if len(my_squad) >= 11:
                            print("🔥 KADRO TAMAMLANDI! Artık maça çıkabilirsin!")
                            break
                        
                    except ValueError:
                        print("❌ Lütfen geçerli sayılar girin!")
                
                elif choice == "2":
                    break
                else:
                    print("❌ Geçersiz seçim!")

    except ValueError:
        raise InvalidInputError("Lütfen sayısal girişleri doğru yap.")
    except Exception as e:
        print("Bir hata oluştu:", e)

def view_squad():
    """Mevcut kadroyu göster"""
    if not my_squad:
        print("\n❌ Kadron boş! Önce oyuncu eklemen gerekiyor.")
        return
    
    print(f"\n⭐ KADRON ({len(my_squad)}/11 oyuncu):")
    print("=" * 60)
    
    total_power = 0
    for i, player in enumerate(my_squad, 1):
        power = sum(player.attributes.values())
        total_power += power
        print(f"{i}. {player.name} ({player.age} yaş)")
        print(f"   Pozisyon: {', '.join(player.positions)}")
        print(f"   Güç: {power} | Finishing: {player.attributes.get('Finishing', 0)} | Passing: {player.attributes.get('Passing', 0)}")
        print("-" * 40)
    
    print(f"💪 TOPLAM TAKIM GÜCÜ: {total_power}")
    print(f"📊 ORTALAMA OYUNCU GÜCÜ: {total_power // len(my_squad) if my_squad else 0}")

def generate_opponent_team():
    """Rakip takım oluştur"""
    opponent = []
    available_players = [p for p in all_players if p not in my_squad]
    
    if len(available_players) < 11:
        # Yeteri kadar oyuncu yoksa rastgele kopyalar oluştur
        while len(available_players) < 11:
            original = random.choice(all_players)
            # Basit kopya oluştur
            copy_player = Player(
                name=f"{original.name} (Rakip)",
                age=original.age,
                positions=",".join(original.positions),
                attributes=original.attributes.copy()
            )
            available_players.append(copy_player)
    
    opponent = random.sample(available_players, 11)
    return opponent

def play_match():
    """Maç simülasyonu"""
    if len(my_squad) < 11:
        print(f"❌ Maça çıkmak için 11 oyuncun olması gerekiyor! Şu an {len(my_squad)}/11 oyuncun var.")
        return
    
    print("\n⚽ MAÇ BAŞLIYOR!")
    print("=" * 50)
    
    # Rakip takım oluştur
    opponent = generate_opponent_team()
    
    print("🏠 SENİN TAKIM:")
    team_power = sum(sum(p.attributes.values()) for p in my_squad)
    print(f"   Toplam Güç: {team_power}")
    
    print("\n🚌 RAKİP TAKIM:")
    opponent_power = sum(sum(p.attributes.values()) for p in opponent)
    print(f"   Toplam Güç: {opponent_power}")
    
    print("\n🎮 Maç simülasyonu başlıyor...")
    input("Devam etmek için ENTER'a bas...")
    
    # Maç simülasyonu
    result, score1, score2 = simulate_match(my_squad, opponent)
    
    print(f"\n🏆 MAÇ SONUCU: {score1}-{score2}")
    print(f"📢 {result}")
    
    if "Kazandın" in result:
        print("🎉 Tebrikler! Harika bir performans sergiledi!")
    else:
        print("😞 Üzülme, bir dahaki sefere daha iyi olacak!")

def debug_players():
    """Tüm oyuncuları göster - test amaçlı"""
    print(f"\n🔍 TOPLAM OYUNCU SAYISI: {len(all_players)}")
    
    if all_players:
        print("\nİlk 5 oyuncu:")
        for i, p in enumerate(all_players[:5], 1):
            print(f"{i}. {p.name} - Yaş: {p.age} - Pos: {', '.join(p.positions)}")
            print(f"   Özellikler: {p.attributes}")
        
        # Pozisyon dağılımı
        all_positions = []
        for p in all_players:
            all_positions.extend(p.positions)
        
        from collections import Counter
        pos_count = Counter(all_positions)
        print(f"\n📊 Pozisyon Dağılımı: {dict(pos_count.most_common(10))}")

def main_menu():
    while True:
        print("\n🔵 FM24 Scouting Uygulaması")
        print("[1] Oyuncu ara ve kadroya ekle")
        print("[2] Kadroyu gör")
        print("[3] Maça çık" + (" ✅" if len(my_squad) >= 11 else " ❌"))
        print("[4] Debug - Oyuncu listesi")
        print("[5] Çıkış")
        
        choice = input("Seçimin: ").strip()
        
        if choice == "1":
            player_search_menu()
        elif choice == "2":
            view_squad()
        elif choice == "3":
            play_match()
        elif choice == "4":
            debug_players()
        elif choice == "5":
            print("Çıkış yapılıyor...")
            break
        else:
            print("❌ Geçersiz seçim!")

if __name__ == "__main__":
    print("🚀 FM24 Scouting Uygulaması Başlatılıyor...")
    
    # Oyuncu verilerini yükle
    load_players()
    
    # Ana menüyü başlat
    main_menu()