import random

def simulate_match(team1, team2):
    """İki takım arasında maç simülasyonu yapar"""
    
    def calculate_team_power(team):
        """Takımın toplam gücünü hesapla"""
        base_power = sum(sum(p.attributes.values()) for p in team)
        # %15 rastgelelik ekle (futbolun doğasında var)
        luck_factor = random.uniform(-0.15, 0.15)
        return base_power * (1 + luck_factor)
    
    # Takım güçlerini hesapla
    power1 = calculate_team_power(team1)
    power2 = calculate_team_power(team2)
    
    # Skor hesaplama (güç oranına göre)
    max_goals = 4  # Bir takımın maksimum atabileceği gol
    total_power = power1 + power2
    
    # Daha gerçekçi skor hesaplama
    score1 = max(0, round((power1 / total_power) * max_goals * random.uniform(0.6, 1.4)))
    score2 = max(0, round((power2 / total_power) * max_goals * random.uniform(0.6, 1.4)))
    
    # Çok yüksek skorları önle
    if score1 > 5:
        score1 = 5
    if score2 > 5:
        score2 = 5
    
    # Beraberlik durumu
    if score1 == score2:
        # %25 şansla penaltılara gitsin
        if random.random() < 0.25:
            penalty1 = random.randint(3, 5)
            penalty2 = random.randint(3, 5)
            # Penaltıda beraberlik olmasın
            while penalty1 == penalty2:
                penalty2 = random.randint(3, 5)
            
            if penalty1 > penalty2:
                return f"Penaltılarla Kazandın! ({score1}-{score2}, {penalty1}-{penalty2} pen.)", score1, score2
            else:
                return f"Penaltılarla Kaybettin... ({score1}-{score2}, {penalty1}-{penalty2} pen.)", score1, score2
        else:
            return "Berabere!", score1, score2
    
    # Normal sonuç
    if score1 > score2:
        margin = score1 - score2
        if margin >= 3:
            return "Büyük Farkla Kazandın! 🔥", score1, score2
        elif margin == 2:
            return "Rahat Kazandın! 👏", score1, score2
        else:
            return "Zor Kazandın! 😅", score1, score2
    else:
        margin = score2 - score1
        if margin >= 3:
            return "Ağır Yenilgi... 😞", score1, score2
        elif margin == 2:
            return "Kaybettin... 😔", score1, score2
        else:
            return "Az Farkla Kaybettin... 😐", score1, score2

def get_match_commentary(score1, score2, team1_power, team2_power):
    """Maç yorumu oluştur"""
    power_diff = abs(team1_power - team2_power)
    
    if power_diff < 50:
        return "Bu çok dengeli bir maçtı! Her iki takım da mücadele etti."
    elif team1_power > team2_power:
        return "Kağıt üzerinde favoriydin ve bunu sahada da gösterdin!"
    else:
        return "Rakip daha güçlüydü ama sen harika mücadele ettin!"