import pandas as pd
from scout import Player

def filter_players(player_list, age_limit, position, criteria):
    """Oyuncuları belirtilen kriterlere göre filtrele"""
    return list(filter(lambda p: p.matches(age_limit, position, criteria), player_list))

def sort_players_by_attribute(players, primary_attr):
    """Oyuncuları belirtilen özelliğe göre sırala ve detaylı bilgi göster"""
    sorted_players = sorted(players, key=lambda p: p.attributes.get(primary_attr, 0), reverse=True)
    
    if sorted_players:
        print(f"\n📈 {primary_attr} özelliğine göre sıralama:")
        print(f"En iyi: {sorted_players[0].attributes.get(primary_attr, 0)}")
        print(f"En düşük: {sorted_players[-1].attributes.get(primary_attr, 0)}")
        print(f"Ortalama: {sum(p.attributes.get(primary_attr, 0) for p in sorted_players) // len(sorted_players)}")
    
    return sorted_players

def load_players_from_dataframe(df, required_attrs):
    """DataFrame'den oyuncu listesi oluştur"""
    column_mapping = {
        "attacking_finishing": "Finishing",
        "passing": "Passing",
        "skill_dribbling": "Dribbling",
        "skill_ball_control": "Ball Control",
        "attacking_short_passing": "First Touch"  # Daha uygun eşleşme
    }
    
    players = []
    error_count = 0
    for index, row in df.iterrows():
        try:
            name = row.get('short_name', row.get('name', 'Unknown'))
            age = int(row.get('age', 25))
            positions = row.get('player_positions', 'CM')
            
            attributes = {}
            for attr in required_attrs:
                csv_column = next((k for k, v in column_mapping.items() if v == attr), attr)
                value = row.get(csv_column, 10)
                if pd.isna(value):
                    value = 10
                attributes[attr] = int(value)
            
            player = Player(name, age, positions, attributes)
            players.append(player)
            
        except Exception as e:
            error_count += 1
            print(f"Hata oluştu, satır {index} atlanıyor: {e}")
            continue
    
    print(f"Toplam {error_count} satırda hata oluştu.")
    return players